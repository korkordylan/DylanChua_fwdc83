#pragma once
#include <vector>

void gram_schmidt(std::vector<std::vector<double>> &A);

double inner_product(const std::vector<double> &u, const std::vector<double> &v);

void lll_reduction(std::vector<std::vector<double>> &basis, double delta);

std::vector<std::vector<double>> parseFormattedInput(const std::string &formattedInput);

double enumerate(const std::vector<std::vector<double>> &basis);
