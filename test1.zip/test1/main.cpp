#include <iostream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdexcept>
#include <fstream>
#include "svp.h"

int main(int argc, char *argv[])
{
    std::ostringstream concatenatedArgs;
    for (int i = 1; i < argc; ++i)
    {
        concatenatedArgs << argv[i] << ",";
    }
    // std::cout << concatenatedArgs.str() << std::endl;
    std::string formattedInput = concatenatedArgs.str();
    for (size_t i = 0; i < formattedInput.length(); ++i)
    {
        if (formattedInput[i] == ']' && formattedInput[i + 1] == ',')
        {
            formattedInput[i + 1] = ' ';
        }
    }
    // std::cout << "Formatted Input: " << formattedInput << std::endl;
    std::vector<std::vector<double>> A = parseFormattedInput(formattedInput);
    double delta = 0.75;
    try
    {
        gram_schmidt(A);
        // Print the resulting matrix
        // for (size_t i = 0; i < A.size(); ++i)
        // {
        //     for (size_t j = 0; j < A[i].size(); ++j)
        //     {
        //         std::cout << A[i][j] << " ";
        //     }
        //     std::cout << std::endl;
        // }
        lll_reduction(A, delta);
        // Print the LLL Reduced Basis
        // std::cout << "LLL Reduced Basis:" << std::endl;
        // for (const auto &vec : A)
        // {
        //     for (double val : vec)
        //     {
        //         std::cout << val << " ";
        //     }
        //     std::cout << std::endl;
        // }
        double shortest_length = enumerate(A);

        // std::ofstream resultFile("result.txt");
        // if (resultFile.is_open())
        // {
        //     resultFile << shortest_length << std::endl;
        //     resultFile.close();
        //     std::cout << "Result saved in 'result.txt'" << std::endl;
        // }
        // else
        // {
        //     std::cerr << "Error: Unable to open 'result.txt' for writing." << std::endl;
        //     return 1; // Return an error code
        // }

        std::string resultFilePath = std::string(getenv("PWD")) + "/result.txt";

        // Save the result to 'result.txt'
        std::ofstream resultFile(resultFilePath);
        if (resultFile.is_open())
        {
            resultFile << shortest_length << std::endl;
            resultFile.close();
            // std::cout << "Result saved in '" << resultFilePath << "'" << std::endl;
        }
        else
        {
            std::cerr << "Error: Unable to open '" << resultFilePath << "' for writing." << std::endl;
            return 1; // Return an error code
        }
    }

    catch (const std::runtime_error &e)
    {
        std::cerr << "Error: " << e.what() << '\n';
    }

    return 0;
}