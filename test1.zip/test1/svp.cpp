#include <iostream>
#include <vector>
#include <sstream>
#include <cmath>
#include <stdexcept>
#include <fstream>
#include "svp.h"
#include <limits>

void gram_schmidt(std::vector<std::vector<double>> &A)
{
    size_t n = A.size();
    size_t m = A[0].size();
    const double epsilon = 1e-10;

    std::vector<std::vector<double>> copyA = A;

    for (size_t i = 0; i < m; ++i)
    {
        std::vector<double> q(n);
        for (size_t k = 0; k < n; ++k)
        {
            q[k] = copyA[k][i];
        }

        for (size_t j = 0; j < i; ++j)
        {
            double dot_product = 0.0;
            for (size_t k = 0; k < n; ++k)
            {
                dot_product += copyA[k][j] * copyA[k][i];
            }
            for (size_t k = 0; k < n; ++k)
            {
                q[k] -= dot_product * copyA[k][j];
            }
        }

        double norm = 0.0;
        for (size_t k = 0; k < n; ++k)
        {
            norm += q[k] * q[k];
        }
        norm = std::sqrt(norm);

        if (norm < epsilon)
        {
            throw std::runtime_error("The column vectors are not linearly independent");
        }

        for (size_t k = 0; k < n; ++k)
        {
            q[k] /= norm;
        }

        for (size_t k = 0; k < n; ++k)
        {
            A[k][i] = q[k];
        }
    }
}
// get inner product of 2 vectors
double inner_product(const std::vector<double> &u, const std::vector<double> &v)
{
    double result = 0.0;
    for (size_t i = 0; i < u.size(); ++i)
    {
        result += u[i] * v[i];
    }
    return result;
}

void lll_reduction(std::vector<std::vector<double>> &basis, double delta)
{
    size_t n = basis.size();
    size_t m = basis[0].size();

    gram_schmidt(basis);

    size_t k = 2;
    while (k <= n - 1)
    {
        for (size_t j = k - 1; j > 0; --j)
        {
            double mu = inner_product(basis[k], basis[j]) / inner_product(basis[j], basis[j]);

            if (std::abs(mu) > 0.5)
            {
                for (size_t i = 0; i < n; ++i)
                {
                    basis[i][k] -= std::floor(mu) * basis[i][j];
                }

                gram_schmidt(basis);
            }
        }

        double bk_norm_square = inner_product(basis[k], basis[k]);
        double condition = delta - std::pow(inner_product(basis[k], basis[k - 1]), 2) * inner_product(basis[k - 1], basis[k - 1]);

        if (bk_norm_square > condition)
        {
            k++;
        }
        else
        {
            std::swap(basis[k], basis[k - 1]);

            gram_schmidt(basis);

            k = std::max(k - 1, static_cast<size_t>(2));
        }
    }
}

std::vector<std::vector<double>> parseFormattedInput(const std::string &formattedInput)
{
    std::vector<std::vector<double>> A;
    std::vector<double> currentRow;
    std::string numericValue;

    for (char ch : formattedInput)
    {
        if (ch == '[')
        {
            currentRow.clear();
            numericValue.clear();
        }
        else if (ch == ',' || ch == ']')
        {
            if (!numericValue.empty())
            {
                currentRow.push_back(std::stod(numericValue));
                numericValue.clear();
            }
            if (ch == ']')
            {
                A.push_back(currentRow);
            }
        }
        else if (std::isdigit(ch) || ch == '.' || ch == '-')
        {
            numericValue += ch;
        }
    }

    return A;
}

double enumerate(const std::vector<std::vector<double>> &basis)
{
    double min_length = std::numeric_limits<double>::infinity();
    size_t dimensions = basis.size();

    // create a vector to store the coefficients for each dimension
    std::vector<int> coefficients(dimensions, 0);

    // iterate through all possible integer coefficients for each dimension
    for (size_t dim = 0; dim < dimensions; ++dim)
    {
        int coeff = 1;
        coefficients[dim] = coeff;

        // create a temp vector
        std::vector<double> tempVector(dimensions, 0.0);
        for (size_t i = 0; i < dimensions; ++i)
        {
            for (size_t coord = 0; coord < basis[i].size(); ++coord)
            {
                tempVector[i] += coefficients[i] * basis[i][coord];
            }
        }
        // length of the temp vector
        double length = std::sqrt(inner_product(tempVector, tempVector));

        // add a checker in case length is 0
        if (length > 1e-10 && length < min_length)
        {
            min_length = length;
        }
        // }
    }
    return min_length;
}